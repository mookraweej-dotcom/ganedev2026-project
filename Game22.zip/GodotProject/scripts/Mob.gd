extends RigidBody2D
# สคริปต์ "ศัตรูในฟาร์ม" เช่น หนู แมลงศัตรูพืช หรืออีกาที่บินเข้ามากินพืชผล

func _ready():
	$AnimatedSprite2D.play()
	# ถ้ามีศัตรูหลายแบบใน SpriteFrames (เช่น "rat", "bug", "crow")
	# จะสุ่มเลือกแบบใดแบบหนึ่งมาแสดงทุกครั้งที่เกิดใหม่
	var mob_types = $AnimatedSprite2D.sprite_frames.get_animation_names()
	if mob_types.size() > 0:
		$AnimatedSprite2D.animation = mob_types[randi() % mob_types.size()]

func _on_visible_on_screen_notifier_2d_screen_exited():
	queue_free()
