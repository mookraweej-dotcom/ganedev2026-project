extends Node

@export var mob_scene: PackedScene
var score

func _ready():
	$Player.hit.connect(_on_player_hit)
	$HUD.start_game.connect(new_game)

func game_over():
	$ScoreTimer.stop()
	$MobTimer.stop()
	$Music.stop()
	$DeathSound.play()
	$HUD.show_game_over()
	$HUD.show_message("Game Over")

func new_game():
	score = 0
	$Player.start(Vector2(240, 450))
	$StartTimer.start()
	$HUD.update_score(score)
	$HUD.show_message("Get Ready")
	get_tree().call_group("mobs", "queue_free")
	$Music.play()

func _on_score_timer_timeout():
	score += 1
	$HUD.update_score(score)

func _on_start_timer_timeout():
	$MobTimer.start()
	$ScoreTimer.start()

func _on_player_hit():
	game_over()

func _on_mob_timer_timeout():
	# สุ่ม "ศัตรูในฟาร์ม" เช่น หนู แมลง หรืออีกา ให้วิ่งเข้ามาในทุ่ง
	var mob = mob_scene.instantiate()
	var screen_size = get_viewport().get_visible_rect().size
	# เลือกขอบจอแบบสุ่มที่จะให้ศัตรูวิ่งเข้ามา: 0=บน, 1=ขวา, 2=ล่าง, 3=ซ้าย
	var edge = randi() % 4
	var spawn_pos = Vector2.ZERO
	var direction = 0.0
	match edge:
		0: # บน วิ่งลง
			spawn_pos = Vector2(randf_range(0, screen_size.x), -50)
			direction = PI / 2
		1: # ขวา วิ่งซ้าย
			spawn_pos = Vector2(screen_size.x + 50, randf_range(0, screen_size.y))
			direction = PI
		2: # ล่าง วิ่งขึ้น
			spawn_pos = Vector2(randf_range(0, screen_size.x), screen_size.y + 50)
			direction = -PI / 2
		3: # ซ้าย วิ่งขวา
			spawn_pos = Vector2(-50, randf_range(0, screen_size.y))
			direction = 0.0
	mob.position = spawn_pos
	direction += randf_range(-PI / 4, PI / 4)
	mob.rotation = direction
	mob.linear_velocity = Vector2(randf_range(150.0, 250.0), 0.0).rotated(direction)
	add_child(mob)
	mob.add_to_group("mobs")
