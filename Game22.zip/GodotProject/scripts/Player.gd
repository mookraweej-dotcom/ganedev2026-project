extends Area2D
# สคริปต์ตัวละครผู้เล่น: "ชาวนา" ที่ต้องหลบศัตรูในฟาร์ม (หนู/แมลง/อีกา)

signal hit

@export var speed = 400  # ความเร็วในการเดินของชาวนา (พิกเซล/วินาที)
var screen_size

func _ready():
	screen_size = get_viewport_rect().size
	hide()
	$CollisionShape2D.set_deferred("disabled", true)

func start(pos):
	position = pos
	show()
	$CollisionShape2D.disabled = false

func _process(delta):
	var velocity = Vector2.ZERO

	if Input.is_action_pressed("move_right"):
		velocity.x += 1
	if Input.is_action_pressed("move_left"):
		velocity.x -= 1
	if Input.is_action_pressed("move_down"):
		velocity.y += 1
	if Input.is_action_pressed("move_up"):
		velocity.y -= 1

	if velocity.length() > 0:
		velocity = velocity.normalized() * speed
		$AnimatedSprite2D.play("walk")
	else:
		$AnimatedSprite2D.stop()

	position += velocity * delta
	position = position.clamp(Vector2.ZERO, screen_size)

	# พลิกภาพชาวนาให้หันตามทิศทางที่เดิน
	if velocity.x != 0:
		$AnimatedSprite2D.flip_h = velocity.x < 0

func _on_body_entered(_body):
	hide()
	hit.emit()
	$CollisionShape2D.set_deferred("disabled", true)
